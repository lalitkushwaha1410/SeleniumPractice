package com.selenium.advanced;

public class Handling_ExplicitWait {

	public static void main(String[] args) 
	{
		
	}

}
